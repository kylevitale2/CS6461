//Class to save the register values
public class gpr {
    public static word R0;
    public static word R1;
    public static word R2;
    public static word R3;
}
