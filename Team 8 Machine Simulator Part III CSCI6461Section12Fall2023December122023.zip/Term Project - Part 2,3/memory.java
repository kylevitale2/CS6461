public class memory {
    public static word[] memory;
}
