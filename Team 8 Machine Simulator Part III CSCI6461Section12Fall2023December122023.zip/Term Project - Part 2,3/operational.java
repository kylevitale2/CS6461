import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

//Handles most backend processes
public class operational {
    public static boolean[] PC;
    public static boolean[] MAR;
    public static word MBR;
    public static word IR;
    public static boolean[] MFR;
    public static boolean Priv;
    public static boolean[] CC;
    public static String printerContents;
    public static char keyboardCharacter;
    public static boolean keyboardStatus;

    //MOVED MEMORY TO SEPARATE JAVA FILE TO DEMONSTRATE LOCALITY
    //public static word[] memory;

    //FULLY ASSOCIATIVE UNIFIED CACHE
    public static cacheLine[] cache;

    public static int cacheLineNumber;
    
    //Stores the MBR into memory at MAR
    public static void Store(){
        int address = binToDec(MAR);
        if(address >= memory.memory.length){
            System.out.println("Error: Out of memory bounds");
            return;
        }
        memory.memory[address].overWrite(MBR);
    }

    //Same as store, but increments MAR
    public static void StorePlus(){
        Store();
        increment(MAR);
    }

    //binary to decimal
    public static int binToDec(boolean[] bin){
        //if bin starts with true, it is negative
        if(bin[0] == true){
            int dec = (int)Math.pow(2, bin.length-1);
            int multiplier = 1;
            for(int i = bin.length-1; i>=1; i--){
                dec += multiplier * (bin[i] ? 1 : 0);
                multiplier *=2;
            }
            return dec;
        }
        int dec = 0;
        int multiplier = 1;
        for(int i = bin.length-1; i>=0; i--){
            dec += multiplier * (bin[i] ? 1 : 0);
            multiplier *=2;
        }
        return dec;
    }

    //decimal to binary
    public static boolean[] decToBin(int dec, int indexCount){
        if(dec >= 0){
            String bin = Integer.toBinaryString(dec);
            boolean[] result = new boolean[indexCount];
            if(bin.length()>indexCount){
                System.out.println("Binary overflow");
                return null;
            }

            while(bin.length() < indexCount){
                bin = "0" + bin;
            }

            for(int i = 0; i<indexCount; i++){
                if(bin.charAt(i) == '0')
                    result[i] = false;
                else
                    result[i] = true;
            }

            return result;
        }
        else{
            String bin = Integer.toBinaryString(dec);
            boolean[] result = new boolean[indexCount];
            for(int i = bin.length()-1; i>=bin.length()-indexCount; i--){
                if(bin.charAt(i) == '0')
                    result[result.length-1-(bin.length()-1-i)] = false;
                else
                    result[result.length-1-(bin.length()-1-i)] = true;
            }

            return result;
        }
    }

    //increment binary
    public static void increment(boolean[] bin){
        for(int i = bin.length-1; i>=0; i--){
            if(bin[i]){
                bin[i] = false;
            }
            else{
                bin[i] = true;
                return;
            }
        }
    }

    //converts a string to a 'binary' array
    public static boolean[] binaryStringToBinary(String s){
        boolean[] bin = new boolean[s.length()];
        for(int i = 0; i<bin.length; i++){
            bin[i] = ('1' == s.charAt(i));
        }
        return bin;
    }

    //convert binary to string
    public static String binaryToString(boolean[] binary){
        String val = "";
        for(int i = 0; i<binary.length; i++)
            val += (binary[i] ? 1 : 0);
        return val;
    }

    //forward operation to string format
    public static void decodeOpcode(boolean[] instruction){
        decodeOpcode(binaryToString(instruction));
    }

    //decode operation
    public static boolean decodeOpcode(String instruction){
        int opCode = binToDec(binaryStringToBinary(instruction.substring(0, 6)));
        int gprReg = binToDec(binaryStringToBinary(instruction.substring(6, 8)));
        int indexReg = binToDec(binaryStringToBinary(instruction.substring(8, 10)));
        int address = binToDec(binaryStringToBinary(instruction.substring(11)));
        int EA;
        word genR;
        word inR;

        //Evaluate what the general purpose register is
        if(gprReg == 0)
            genR = gpr.R0;
        else if(gprReg == 1)
            genR = gpr.R1;
        else if(gprReg == 2)
            genR = gpr.R2;
        else
            genR = gpr.R3;

        //Evaluate what the index register is
        if(indexReg == 1)
            inR = index.X1;
        else if(indexReg == 2)
            inR = index.X2;
        else if(indexReg == 3)
            inR = index.X3;
        else
            inR = null;


        //Compute the effective address (EA)
        //direct address
        if(instruction.charAt(10) == '0'){
            if(indexReg == 0){
                EA = address;
            }
            else{
                EA = operational.binToDec(inR.toBitArray()) + address;
            }
        }
        //indirect addressing
        else{
            if(indexReg == 0){
                EA = operational.binToDec(memory.memory[address].toBitArray());
            }
            else{
                EA = operational.binToDec(memory.memory[address+operational.binToDec(inR.toBitArray())].toBitArray());
            }
        }

        //Halt program operation
        if(opCode == 0){
            System.out.println("Halt program");
            gui.halt.setText("1");
            return true;
        }

        /**
         * LDR
         * Load Register From Memory, r = 0..3 
            r <- c(EA) 
         */
        else if (opCode == 1){
            genR.overWrite(memory.memory[EA]);
        }

        /**
         * STR
         * Store Register To Memory, r = 0..3 
         *  Memory(EA) <- c(r) 
         * THIS UPDATES WITH CACHE INVOLVED

         */
        else if (opCode == 2){
            memory.memory[EA].overWrite(genR);
            cache[cacheLineNumber].addressTag = EA;
            cache[cacheLineNumber].valid = true;
            cache[cacheLineNumber].data.overWrite(genR);
            cacheLineNumber = (cacheLineNumber +1)%16;

        }

        /**
         * LDA
         * Load Register with Address, r = 0..3 
         * r <- EA 
         */
        else if (opCode == 3){
            boolean hit = false;
            for(int i = 0; i<cache.length; i++){
                if(cache[i].addressTag == EA && cache[i].valid){
                    inR.overWrite(cache[i].data);
                    hit = true;
                }
                if(!cache[i].valid)
                    break;
            }
            if(!hit)
                genR.overWrite(new word(operational.decToBin(EA, 16)));
        }

        /*
         * LDX
         * Load Index Register from Memory, x = 1..3 
            Xx <- c(EA)
         */
        else if (opCode == 33){
            boolean hit = false;
            for(int i = 0; i<cache.length; i++){
                if(cache[i].addressTag == EA && cache[i].valid){
                    inR.overWrite(cache[i].data);
                    hit = true;
                }
                if(!cache[i].valid)
                    break;
            }
            if(!hit)
                inR.overWrite(memory.memory[EA]);
        }

        /*
         * STX
         * Store Index Register to Memory. X = 1..3 
         * Memory(EA) <- c(Xx)
         */
        else if (opCode == 34){
            memory.memory[EA].overWrite(inR);
            cache[cacheLineNumber].addressTag = EA;
            cache[cacheLineNumber].valid = true;
            cache[cacheLineNumber].data.overWrite(inR);
            cacheLineNumber = (cacheLineNumber+1)%16;
        }

        /*
         * JZ
         * Jump if Zero
         * If c(r) = 0, then PC  EA 
            Else PC <- PC+1 
         */
        else if(opCode == 8){
            if(binToDec(genR.toBitArray()) == 0){
                PC = operational.decToBin(EA-1, 12) ;
            }
        }

        /*
         * JNE
         * If c(r) != 0, then PC - EA 
            Else PC <- PC + 1
         */
         else if(opCode == 9){
            if(binToDec(genR.toBitArray()) != 0){
                PC = operational.decToBin(EA-1, 12) ;
            }
         }

         /*
          * JCC
          cc replaces r for this instruction 
            cc takes values 0, 1, 2, 3 as above and specifies 
            the bit in the Condition Code Register to check; 
            If cc bit = 1, PC  EA 
            Else PC <- PC + 1 

          */
        else if(opCode == 10){
            if(CC[gprReg]){
                PC = operational.decToBin(EA-1, 12) ;
            }
        }

        /*
         * JMA
         * Unconditional Jump To Address 
            PC <- EA,
         */
        else if(opCode == 11){
            PC = operational.decToBin(EA-1, 12);
        }

        /*
         * JSR
         * R3 <- PC+1; 
            PC <- EA 
            R0 should contain pointer to arguments 
            Argument list should end with –1 (all 1s) value
         */
        else if(opCode == 12){
            gpr.R3.overWrite(new word(binaryToString(PC)));
            PC = decToBin(EA-1, 12);
        }

        /*
         * RFS
         * Return From Subroutine w/ return code as Immed 
            portion (optional) stored in the instruction’s 
            address field. 
            R0  Immed; PC  c(R3) 
            IX, I fields are ignored.

         */

        else if(opCode == 13){
            gpr.R0.overWrite(new word(decToBin(address, 16)));
            PC = decToBin(binToDec(gpr.R3.toBitArray())-1, 12);
        }

        /*
         * SOB
         *  r <- c(r) – 1 
            If c(r) > 0, PC <- EA; 
            Else PC <- PC + 1
         */
        else if(opCode == 14){
            genR.overWrite(new word(decToBin(binToDec(genR.toBitArray()) - 1, 16)));

            if(binToDec(genR.toBitArray()) > 0){
                PC = decToBin(EA-1, 12);
            }

            //increments after step regardless
        }

        /*
         * JGE
         * If c(r) >= 0, then PC <- EA 
            Else PC <- PC + 1

         */
        else if(opCode == 15){
            if(binToDec(genR.toBitArray()) >= 0){
                PC = decToBin(EA-1, 12);
            }
        }

        /*
         * AMR
         * Add Memory To Register, r = 0..3 
            r<- c(r) + c(EA) 
         */
        else if(opCode == 4){
            genR.overWrite(new word(decToBin((binToDec(genR.toBitArray()) + binToDec(memory.memory[EA].toBitArray())), 16)));
        }

        /*
         * SMR
         * Subtract Memory From Register, r = 0..3 
            r<- c(r) – c(EA) 

         */
        else if(opCode == 5){
            genR.overWrite(new word(decToBin((binToDec(genR.toBitArray()) - binToDec(memory.memory[EA].toBitArray())), 16)));
        }

        /*
         * AIR
         * Add Immediate to Register, r = 0..3 
            r <- c(r) + Immed 
         */
        else if(opCode == 6){
            genR.overWrite(new word(decToBin((binToDec(genR.toBitArray()) + address), 16)));
        }

        /*
            SIR
         * Subtract Immediate from Register, r = 0..3 
            r  c(r) - Immed 
         */
        else if (opCode == 7) {
            genR.overWrite(new word(decToBin((binToDec(genR.toBitArray()) - address), 16)));
        }

        /*
         * MLT
         * Multiply Register by Register 
            rx, rx+1 <- c(rx) * c(ry) 
            rx must be 0 or 2 
            ry must be 0 or 2 

            rx contains the high order bits, rx+1 contains the 
            low order bits of the result 
            Set OVERFLOW flag, if overflow

         */
        else if(opCode == 16){
            if(gprReg%2 ==1 || indexReg%2 == 1){
                //DO NOTHING
            }
            else{
                boolean[] tempX = genR.toBitArray();
                boolean[] tempY;
                if(indexReg == 0)
                    tempY = gpr.R0.toBitArray();
                else if(indexReg == 1)
                    tempY = gpr.R1.toBitArray();
                else if(indexReg == 2)
                    tempY = gpr.R2.toBitArray();
                else
                    tempY = gpr.R3.toBitArray();

                long valX = binToDec(tempX);
                long valY = binToDec(tempY);
                long out = valX*valY;
                int outVal;
                //CHECK OVERFLOW
                if(out > (long)(2147483647)){
                    CC[0] = true;
                }
                outVal = (int)out;
                boolean[] tempOut = decToBin(outVal, 32);
                genR.overWrite(new word(Arrays.copyOfRange(tempOut, 0, 16)));
                if(gprReg == 0){
                    gpr.R1.overWrite(new word(Arrays.copyOfRange(tempOut, 16, 32)));
                }
                else{
                    gpr.R3.overWrite(new word(Arrays.copyOfRange(tempOut, 16, 32)));
                }
                
            }
        }

        /*
         * DVD
         * Divide Register by Register 
            rx, rx+1 <- c(rx)/ c(ry) 
            rx must be 0 or 2 
            rx contains the quotient; rx+1 contains the 
            remainder 
            ry must be 0 or 2 
            If c(ry) = 0, set cc(3) to 1 (set DIVZERO flag)

         */
        else if(opCode == 17){
            if(gprReg%2 ==1 || indexReg%2 == 1){
                //DO NOTHING
            }
            else{
                boolean[] tempX = genR.toBitArray();
                boolean[] tempY;
                if(indexReg == 0)
                    tempY = gpr.R0.toBitArray();
                else if(indexReg == 1)
                    tempY = gpr.R1.toBitArray();
                else if(indexReg == 2)
                    tempY = gpr.R2.toBitArray();
                else
                    tempY = gpr.R3.toBitArray();

                int valX = binToDec(tempX);
                int valY = binToDec(tempY);
                if(valY == 0){
                    CC[2] = true;
                }
                else{
                    int out = valX/valY;
                    int remainder = valX % valY;
                    boolean[] tempOut = decToBin(out, 16);
                    boolean[] tempRem = decToBin(remainder, 16);
                    genR.overWrite(new word(tempOut));
                    if(gprReg == 0){
                        gpr.R1.overWrite(new word(tempRem));
                    }
                    else{
                        gpr.R3.overWrite(new word(tempRem));
                    }
                }
            }
        }

        /*
         * TRR
         * Test the Equality of Register and Register 
            If c(rx) = c(ry), set cc(4) <- 1; else, cc(4) <- 0 

         */
        else if(opCode == 18){
            boolean[] tempX = genR.toBitArray();
            boolean[] tempY;
            if(indexReg == 0)
                tempY = gpr.R0.toBitArray();
            else if(indexReg == 1)
                tempY = gpr.R1.toBitArray();
            else if(indexReg == 2)
                tempY = gpr.R2.toBitArray();
            else
                tempY = gpr.R3.toBitArray();
            
            if(tempX.toString().equals(tempY.toString())){
                //SET CONDITION CODE cc(3) = 1
                CC[3] = true;
            }
            else{
                //SET CONDITION CODE cc(3) = 0
                CC[3] = false;
            }
        }

        /*
         * AND
         * Logical And of Register and Register 
            c(rx) <- c(rx) AND c(ry) 

         */
        else if(opCode == 19){
            boolean[] tempX = genR.toBitArray();
            boolean[] tempY;
            if(indexReg == 0)
                tempY = gpr.R0.toBitArray();
            else if(indexReg == 1)
                tempY = gpr.R1.toBitArray();
            else if(indexReg == 2)
                tempY = gpr.R2.toBitArray();
            else
                tempY = gpr.R3.toBitArray();

            for(int i = 0; i<tempX.length; i++){
                //setting the value is redundant, but keep anyhow
                if(tempX[i] && tempY[i]){
                    tempX[i] = true;
                }
                else{
                    tempX[i] = false;
                }
            }

            genR.overWrite(new word(tempX));
        }

        /*
         * ORR 
         * Logical Or of Register and Register 
            c(rx) <- c(rx) OR c(ry) 

         */
        else if(opCode == 20){
            boolean[] tempX = genR.toBitArray();
            boolean[] tempY;
            if(indexReg == 0)
                tempY = gpr.R0.toBitArray();
            else if(indexReg == 1)
                tempY = gpr.R1.toBitArray();
            else if(indexReg == 2)
                tempY = gpr.R2.toBitArray();
            else
                tempY = gpr.R3.toBitArray();

            for(int i = 0; i<tempX.length; i++){
                if(tempX[i] || tempY[i]){
                    tempX[i] = true;
                }
                //redundant, but will keep anyhow
                else{
                    tempX[i] = false;
                }
            }

            genR.overWrite(new word(tempX));


        }

        /*
         * NOT
         * Logical Not of Register To Register 
            C(rx) <- NOT c(rx) 

         */
        else if(opCode == 21){
            boolean[] temp = genR.toBitArray();
            for(int i = 0; i<temp.length; i++){
                if(temp[i]){
                    temp[i] = false;
                }
                else{
                    temp[i] = true;
                }
            }
            genR.overWrite(new word(temp));
        }

        /*
         * SRC
         * Shift Register by Count 
            c(r) is shifted left (L/R =1) or right (L/R = 0) either 
            logically (A/L = 1) or arithmetically (A/L = 0) 
            XX, XXX are ignored 
            Count = 0…15 
            If Count = 0, no shift occurs

         */
        else if(opCode == 25){
            int count = binToDec(binaryStringToBinary(instruction.substring(12)));
            if(count < 16){
                boolean[] output = genR.toBitArray(); //reads exactly what is in register
                //Arithmetic shift, keep first bit
                if(instruction.substring(8,9).equals("0")){
                    //RIGHT
                    if(instruction.substring(9,10).equals("0")){
                        for(int i = 0; i<count; i++){
                            for(int j = output.length-1; j>1; j--){
                                output[j] = output[j-1];
                            }
                            output[1] = false;
                        }
                    }
                    //LEFT
                    else{
                        for(int i = 0; i<count; i++){
                            for(int j = 1; j<output.length-2; j++){
                                output[j] = output[j+1];
                            }
                            output[output.length-1] = false;
                        }
                    }
                }
                //Logical shift, don't keep first bit
                else{
                    //RIGHT
                    if(instruction.substring(9,10).equals("0")){
                        for(int i = 0; i<count; i++){
                            for(int j = output.length-1; j>0; j--){
                                output[j] = output[j-1];
                            }
                            output[0] = false;
                        }
                    }
                    //LEFT
                    else{
                        for(int i = 0; i<count; i++){
                            for(int j = 0; j<output.length-2; j++){
                                output[j] = output[j+1];
                            }
                            output[output.length-1] = false;
                        }
                    }
                }
                genR.overWrite(new word(output));
            }
        }

        /*
         * RRC
         * Rotate Register by Count 
            c(r) is rotated left (L/R = 1) or right (L/R =0) either 
            logically (A/L =1) 
            XX, XXX is ignored 
            Count = 0…15 
            If Count = 0, no rotate occurs
         * 
         */
        else if(opCode == 26){
            int count = binToDec(binaryStringToBinary(instruction.substring(12)));
            if(count < 16){
                boolean[] output = genR.toBitArray(); //reads exactly what is in register
                //Arithmetic rotate, keep first bit
                if(instruction.substring(8,9).equals("0")){
                    //RIGHT
                    if(instruction.substring(9,10).equals("0")){
                        for(int i = 0; i<count; i++){
                            boolean temp = output[output.length-1];
                            for(int j = output.length-1; j>1; j--){
                                output[j] = output[j-1];
                            }
                            output[1] = temp;
                        }
                    }
                    //LEFT
                    else{
                        for(int i = 0; i<count; i++){
                            boolean temp = output[1];
                            for(int j = 1; j<output.length-2; j++){
                                output[j] = output[j+1];
                            }
                            output[output.length-1] = temp;
                        }
                    }
                }
                //Logical rotate, don't keep first bit
                else{
                    //RIGHT
                    if(instruction.substring(9,10).equals("0")){
                        for(int i = 0; i<count; i++){
                            boolean temp = output[output.length-1];
                            for(int j = output.length-1; j>0; j--){
                                output[j] = output[j-1];
                            }
                            output[0] = temp;
                        }
                    }
                    //LEFT
                    else{
                        for(int i = 0; i<count; i++){
                            boolean temp = output[0];
                            for(int j = 0; j<output.length-2; j++){
                                output[j] = output[j+1];
                            }
                            output[output.length-1] = temp;
                        }
                    }
                }
                genR.overWrite(new word(output));
            }
        }

        /*
         * IN
         * Input Character To Register from Device, r = 0..3
         */
        else if(opCode == 49){

        }

        /*
         * OUT
         * Output Character to Device from Register, r = 0..3
         */
        else if(opCode == 50){
            if(address != 1){

            }
            else{
                printerContents += (char)(binToDec(genR.toBitArray()));
            }
        }

        /*
         * CHK
         * Check Device Status to Register, r = 0..3 
            c(r) <- device status
         */
        else if(opCode == 51){
            genR.overWrite(new word("0000000000000001"));
        }

        //unknown operation
        else{
            System.out.println("Unknown Operation");
            return true;
        }

        return false;

    }

    //Runs through a single step in the program
    public static void SS(){
        int address = operational.binToDec(PC);
        decodeOpcode(memory.memory[address].toString());
        operational.increment(PC);
    }

    //Runs through all steps in the program
    public static void Run(){
        int address = operational.binToDec(PC);
        while(!decodeOpcode(memory.memory[address].toString())){
            operational.increment(PC);
            address = operational.binToDec(PC);
        }
    }

    //Loads in the IPL.txt file to load in the program
    public static void Init(){
        File file = new File("./ipl.txt");
        String line;
        int address;
        int instruction;
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            line = br.readLine();
            while (line != null) {
                address = Integer.parseInt(line.substring(0, 4), 16);
                System.out.println(address);
                instruction = Integer.parseInt(line.substring((line.length() - 4)), 16);
                System.out.println(instruction);
                memory.memory[address] = new word(Integer.toBinaryString(instruction));
                line = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
