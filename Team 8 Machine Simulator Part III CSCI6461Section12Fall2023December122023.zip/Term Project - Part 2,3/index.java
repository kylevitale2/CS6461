//Class to save the index values
public class index {
    public static word X1;
    public static word X2;
    public static word X3;
}
