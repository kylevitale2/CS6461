public class run{
    //Where the program is run from
    public static void main(String[] args){
        gui.start();      
    }
}