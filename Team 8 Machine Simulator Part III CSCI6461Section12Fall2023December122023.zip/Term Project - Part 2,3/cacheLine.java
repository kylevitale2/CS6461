public class cacheLine {
    public boolean valid;
    public int addressTag;
    public word data;

    public cacheLine(){
        valid = false;
        addressTag = 0;
        data = new word();
    }
}

